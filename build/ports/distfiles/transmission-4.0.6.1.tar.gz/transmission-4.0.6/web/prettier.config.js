module.exports = {
  "singleQuote": true,
};
