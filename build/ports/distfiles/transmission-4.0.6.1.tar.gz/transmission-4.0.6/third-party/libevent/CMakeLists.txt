#
# Libevent CMake project
#
# Based on initial work by:
#    Alexey Ozeritsky
#
# Additional changes:
#   Brodie Thiesfield
#   Joakim Soderberg
#   Trond Norbye
#   Sergei Nikulov
#
#   Build example:
#
#       cd libevent
#       md build
#       cd build
#       cmake -G "Visual Studio 10" ..
#       start libevent.sln
#

cmake_minimum_required(VERSION 3.1 FATAL_ERROR)

if (POLICY CMP0054)
    cmake_policy(SET CMP0054 NEW)
endif()
if (POLICY CMP0074)
    cmake_policy(SET CMP0074 NEW)
endif()
if (POLICY CMP0075)
    cmake_policy(SET CMP0075 NEW)
endif()

if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Release
        CACHE STRING "Set build type to Debug o Release (default Release)" FORCE)
endif()
string(TOLOWER "${CMAKE_BUILD_TYPE}" CMAKE_BUILD_TYPE_LOWER)

# get rid of the extra default configurations
# what? why would you get id of other useful build types? - Ellzey
# Transmission - we need all configurations
# set(CMAKE_CONFIGURATION_TYPES "Debug;Release" CACHE STRING "Limited configurations" FORCE)

set(EVENT__LIBRARY_TYPE DEFAULT CACHE STRING
    "Set library type to SHARED/STATIC/BOTH (default SHARED for MSVC, otherwise BOTH)")

project(libevent C)

list(APPEND CMAKE_MODULE_PATH "${PROJECT_SOURCE_DIR}/cmake/")
string(REGEX MATCH "SunOS" SOLARIS "${CMAKE_SYSTEM_NAME}")


include(CheckTypeSize)
include(CheckFileOffsetBits)
include(Macros)
include(CheckVariableExists)
include(CheckSymbolExists)
include(CheckStructHasMember)
include(CheckCSourceCompiles)
include(CheckPrototypeDefinition)
include(CheckFunctionKeywords)
include(CheckConstExists)
include(AddCompilerFlags)
include(VersionViaGit)

event_fuzzy_version_from_git()

set(EVENT_VERSION_MAJOR ${EVENT_GIT___VERSION_MAJOR})
set(EVENT_VERSION_MINOR ${EVENT_GIT___VERSION_MINOR})
set(EVENT_VERSION_PATCH ${EVENT_GIT___VERSION_PATCH})
set(EVENT_VERSION_STAGE ${EVENT_GIT___VERSION_STAGE})


set(EVENT_ABI_MAJOR ${EVENT_VERSION_MAJOR})
set(EVENT_ABI_MINOR ${EVENT_VERSION_MINOR})
set(EVENT_ABI_PATCH ${EVENT_VERSION_PATCH})

set(EVENT_ABI_LIBVERSION
    "${EVENT_ABI_MAJOR}.${EVENT_ABI_MINOR}.${EVENT_ABI_PATCH}")

set(EVENT_PACKAGE_VERSION
    "${EVENT_VERSION_MAJOR}.${EVENT_VERSION_MINOR}.${EVENT_VERSION_PATCH}")

set(EVENT_NUMERIC_VERSION 0x02010c00)
# equals to VERSION_INFO in Makefile.am
set(EVENT_ABI_LIBVERSION_CURRENT   7)
set(EVENT_ABI_LIBVERSION_REVISION  1)
set(EVENT_ABI_LIBVERSION_AGE       0)

# equals to RELEASE in Makefile.am
set(EVENT_PACKAGE_RELEASE 2.1)

# only a subset of names can be used, defaults to "beta"
set(EVENT_STAGE_NAME ${EVENT_VERSION_STAGE})

# a list that defines what can set for EVENT_STAGE_VERSION
set(EVENT__ALLOWED_STAGE_NAMES
	rc
	beta
	alpha
	alpha-dev
	release
	stable
)
list(
	FIND EVENT__ALLOWED_STAGE_NAMES
	"${EVENT_STAGE_NAME}"
	EVENT__STAGE_RET
)
if (EVENT__STAGE_RET EQUAL -1)
	message(WARNING
		"stage ${EVENT_STAGE_NAME} is not allowed, reset to beta")
	set(EVENT_STAGE_NAME beta)
endif()

set(EVENT_VERSION
	"${EVENT_VERSION_MAJOR}.${EVENT_VERSION_MINOR}.${EVENT_VERSION_PATCH}-${EVENT_STAGE_NAME}")

option(EVENT__DISABLE_DEBUG_MODE
    "Define if libevent should build without support for a debug mode" OFF)

option(EVENT__ENABLE_VERBOSE_DEBUG
    "Enables verbose debugging" OFF)

option(EVENT__DISABLE_MM_REPLACEMENT
    "Define if libevent should not allow replacing the mm functions" OFF)

option(EVENT__DISABLE_THREAD_SUPPORT
    "Define if libevent should not be compiled with thread support" OFF)

option(EVENT__DISABLE_OPENSSL
    "Define if libevent should build without support for OpenSSL encryption" OFF)

option(EVENT__DISABLE_BENCHMARK
    "Defines if libevent should build without the benchmark executables" OFF)

option(EVENT__DISABLE_TESTS
    "If tests should be compiled or not" OFF)

option(EVENT__DISABLE_REGRESS
    "Disable the regress tests" OFF)

option(EVENT__DISABLE_SAMPLES
    "Disable sample files" OFF)

option(EVENT__DISABLE_CLOCK_GETTIME
    "Do not use clock_gettime even if it is available" OFF)

option(EVENT__FORCE_KQUEUE_CHECK
    "When crosscompiling forces running a test program that verifies that Kqueue works with pipes. Note that this requires you to manually run the test program on the cross compilation target to verify that it works. See cmake documentation for try_run for more details" OFF)

# TODO: Add --disable-largefile     omit support for large files
option(EVENT__COVERAGE
"Enable running gcov to get a test coverage report (only works with GCC/CLang). Make sure to enable -DCMAKE_BUILD_TYPE=Debug as well." OFF)

# Put the libaries and binaries that get built into directories at the
# top of the build tree rather than in hard-to-find leaf directories.
#
# But only if this variables are not defined yet
# (i.e. libevent is used via add_subdirectory())
if (NOT DEFINED CMAKE_RUNTIME_OUTPUT_DIRECTORY)
    set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${PROJECT_BINARY_DIR}/bin)
endif()
if (NOT DEFINED CMAKE_LIBRARY_OUTPUT_DIRECTORY)
    set(CMAKE_LIBRARY_OUTPUT_DIRECTORY ${PROJECT_BINARY_DIR}/lib)
endif()
if (NOT DEFINED CMAKE_ARCHIVE_OUTPUT_DIRECTORY)
    set(CMAKE_ARCHIVE_OUTPUT_DIRECTORY ${PROJECT_BINARY_DIR}/lib)
endif()

if (EVENT__ENABLE_VERBOSE_DEBUG)
    add_definitions(-DUSE_DEBUG=1)
endif()

# make it colorful under ninja-build
if ("${CMAKE_GENERATOR}" STREQUAL "Ninja")
    add_compiler_flags(-fdiagnostics-color=always)
endif()

# Setup compiler flags for coverage.
if (EVENT__COVERAGE)
    if (NOT "${CMAKE_BUILD_TYPE_LOWER}" STREQUAL "debug")
        message(FATAL_ERROR "Coverage requires -DCMAKE_BUILD_TYPE=Debug")
    endif()

    message(STATUS "Setting coverage compiler flags")

    set(CMAKE_REQUIRED_LIBRARIES "--coverage")
    add_compiler_flags(-g -O0 --coverage)
    set(CMAKE_REQUIRED_LIBRARIES "")
endif()

set(GNUC 0)
set(CLANG 0)
set(MSVC 0)
if (("${CMAKE_C_COMPILER_ID}" STREQUAL "Clang") OR
    ("${CMAKE_C_COMPILER_ID}" STREQUAL "AppleClang"))
    set(CLANG 1)
endif()
if (("${CMAKE_C_COMPILER_ID}" STREQUAL "GNU") OR (${CLANG}))
    set(GNUC 1)
endif()
if (("${CMAKE_C_COMPILER_ID}" STREQUAL "MSVC") OR (${CLANG}))
    set(MSVC 1)
endif()

# Detect library type
set(EVENT_LIBRARY_TYPE)
if ("${EVENT__LIBRARY_TYPE}" STREQUAL "DEFAULT")
    if (${MSVC})
        set(EVENT_LIBRARY_TYPE SHARED)
    else()
        set(EVENT_LIBRARY_TYPE BOTH)
    endif()
else()
    string(TOUPPER "${EVENT__LIBRARY_TYPE}" EVENT_LIBRARY_TYPE)
endif()
if ((${MSVC}) AND ("${EVENT_LIBRARY_TYPE}" STREQUAL "BOTH"))
    message(WARNING
      "Building SHARED and STATIC is not supported for MSVC "
      "(due to conflicts in library name"
      " between STATIC library and IMPORTED library for SHARED libraries)")
endif()
set(EVENT_LIBRARY_STATIC OFF)
set(EVENT_LIBRARY_SHARED OFF)
if ("${EVENT_LIBRARY_TYPE}" STREQUAL "BOTH")
    set(EVENT_LIBRARY_STATIC ON)
    set(EVENT_LIBRARY_SHARED ON)
elseif ("${EVENT_LIBRARY_TYPE}" STREQUAL "STATIC")
    set(EVENT_LIBRARY_STATIC ON)
elseif ("${EVENT_LIBRARY_TYPE}" STREQUAL "SHARED")
    set(EVENT_LIBRARY_SHARED ON)
else()
    message(FATAL_ERROR "${EVENT_LIBRARY_TYPE} is not supported")
endif()

if (${MSVC})
    set(msvc_static_runtime OFF)
    if ("${EVENT_LIBRARY_TYPE}" STREQUAL "STATIC")
        set(msvc_static_runtime ON)
    endif()

    # For more info:
    # - https://docs.microsoft.com/en-us/cpp/build/reference/md-mt-ld-use-run-time-library?view=vs-2017
    # - https://gitlab.kitware.com/cmake/community/wikis/FAQ#how-can-i-build-my-msvc-application-with-a-static-runtime
    option(EVENT__MSVC_STATIC_RUNTIME
           "Link static runtime libraries"
           ${msvc_static_runtime})

    if (EVENT__MSVC_STATIC_RUNTIME)
        foreach (flag_var
                 CMAKE_C_FLAGS_DEBUG
                 CMAKE_C_FLAGS_RELEASE
                 CMAKE_C_FLAGS_MINSIZEREL
                 CMAKE_C_FLAGS_RELWITHDEBINFO
        )
            if (${flag_var} MATCHES "/MD")
                string(REGEX REPLACE "/MD" "/MT" ${flag_var} "${${flag_var}}")
            endif()
        endforeach()
    endif()
endif()

# GNUC specific options.
if (${GNUC})
    option(EVENT__DISABLE_GCC_WARNINGS "Disable verbose warnings with GCC" OFF)
    option(EVENT__ENABLE_GCC_HARDENING "Enable compiler security checks" OFF)
    option(EVENT__ENABLE_GCC_FUNCTION_SECTIONS "Enable gcc function sections" OFF)
    option(EVENT__ENABLE_GCC_WARNINGS "Make all GCC warnings into errors" OFF)

    set(GCC_V ${CMAKE_C_COMPILER_VERSION})

    list(APPEND __FLAGS
         -Wall -Wextra -Wno-unused-parameter -Wstrict-aliasing -Wstrict-prototypes

         -fno-strict-aliasing # gcc 2.9.5+
         -Wmissing-prototypes

         # gcc 4
         -Winit-self
         -Wmissing-field-initializers
         -Wdeclaration-after-statement

         # gcc 4.2
         -Waddress
         -Wnormalized=id
         -Woverride-init

         # gcc 4.5
         -Wlogical-op

         -Wwrite-strings
    )

    if (${CLANG})
        list(APPEND __FLAGS -Wno-unused-function)
    endif()

    if (EVENT__DISABLE_GCC_WARNINGS)
        list(APPEND __FLAGS -w)
    endif()

    if (EVENT__ENABLE_GCC_HARDENING)
        list(APPEND __FLAGS
             -fstack-protector-all
             -fwrapv
             -fPIE
             -Wstack-protector
             "--param ssp-buffer-size=1")

        add_definitions(-D_FORTIFY_SOURCE=2)
    endif()

    if (EVENT__ENABLE_GCC_FUNCTION_SECTIONS)
        list(APPEND __FLAGS -ffunction-sections)
        # TODO: Add --gc-sections support. We need some checks for NetBSD to ensure this works.
    endif()

    if (EVENT__ENABLE_GCC_WARNINGS)
        list(APPEND __FLAGS -Werror)
    endif()

    add_compiler_flags(${__FLAGS})
endif()

if (APPLE)
    # Get rid of deprecated warnings for OpenSSL on OSX 10.7 and greater.
    add_compiler_flags(
        -Wno-error=deprecated-declarations
        -Qunused-arguments
    )
endif()

if (MINGW OR CYGWIN)
    set(WIN32 TRUE)
endif()

# Winsock.
if(WIN32)
    set(CMAKE_REQUIRED_LIBRARIES  ws2_32 shell32 advapi32)
    set(CMAKE_REQUIRED_DEFINITIONS -FIwinsock2.h -FIws2tcpip.h -D_WIN32_WINNT=0x0600)
endif()
if (SOLARIS)
    set(CMAKE_REQUIRED_LIBRARIES socket nsl)
endif()

# Check if _GNU_SOURCE is available.
if (NOT DEFINED _GNU_SOURCE)
  CHECK_SYMBOL_EXISTS(__GNU_LIBRARY__ "features.h" _GNU_SOURCE)

  if (NOT _GNU_SOURCE)
    unset(_GNU_SOURCE CACHE)
    CHECK_SYMBOL_EXISTS(_GNU_SOURCE "features.h" _GNU_SOURCE)
  endif()

  if (ANDROID)
    set(_GNU_SOURCE TRUE)
  endif()
endif()

if (_GNU_SOURCE)
    add_definitions(-D_GNU_SOURCE=1)
    set(CMAKE_REQUIRED_DEFINITIONS -D_GNU_SOURCE)
endif()

# Check if header files exist
list(APPEND FILES_TO_CHECK
    fcntl.h
    inttypes.h
    memory.h
    signal.h
    stdarg.h
    stddef.h
    stdint.h
    stdlib.h
    string.h
    errno.h
    unistd.h
    time.h
    sys/types.h
    sys/stat.h
    sys/time.h
    sys/param.h
)
if (WIN32)
    list(APPEND FILES_TO_CHECK
        io.h
        winsock2.h
        ws2tcpip.h
        afunix.h
    )
else()
    list(APPEND FILES_TO_CHECK
        netdb.h
        dlfcn.h
        arpa/inet.h
        poll.h
        port.h
        sys/socket.h
        sys/random.h
        sys/un.h
        sys/devpoll.h
        sys/epoll.h
        sys/eventfd.h
        sys/event.h
        sys/ioctl.h
        sys/mman.h
        sys/queue.h
        sys/select.h
        sys/sendfile.h
        sys/uio.h
        sys/wait.h
        sys/resource.h
        sys/timerfd.h
        netinet/in.h
        netinet/in6.h
        netinet/tcp.h
        ifaddrs.h
    )
endif()

if (NOT "${CMAKE_HOST_SYSTEM_NAME}" STREQUAL "Linux")
    list(APPEND FILES_TO_CHECK sys/sysctl.h)
endif()

if (APPLE)
    list(APPEND FILES_TO_CHECK
        mach/mach_time.h
        mach/mach.h
    )
endif()

foreach(FILE ${FILES_TO_CHECK})
    CHECK_INCLUDE_FILE_CONCAT(${FILE} "EVENT")
endforeach()
unset(FILES_TO_CHECK)

# Check if functions exist
list(APPEND SYMBOLS_TO_CHECK
    getaddrinfo
    getnameinfo
    getprotobynumber
    getservbyname
    gethostbyname
    inet_ntop
    inet_pton
    gettimeofday
    signal
    strtoll
    splice
    strlcpy
    strsep
    strtok_r
    vasprintf
    timerclear
    timercmp
    timerisset
    timeradd
    nanosleep
    putenv
    umask
)
if (NOT EVENT__DISABLE_CLOCK_GETTIME)
    list(APPEND SYMBOLS_TO_CHECK clock_gettime)
endif()

if (WIN32)
    list(APPEND SYMBOLS_TO_CHECK
        _gmtime64_s
        _gmtime64
    )
else()
    list(APPEND SYMBOLS_TO_CHECK
        getifaddrs
        select
        epoll_create
        epoll_create1
        epoll_ctl
        eventfd
        poll
        port_create
        kqueue
        fcntl
        mmap
        pipe
        pipe2
        sendfile
        sigaction
        strsignal
        sysctl
        accept4
        arc4random
        arc4random_buf
        arc4random_addrandom
        getrandom
        getegid
        geteuid
        issetugid
        usleep
        timerfd_create
        setenv
        unsetenv
        setrlimit
        gethostbyname_r
    )
    if (APPLE)
        list(APPEND SYMBOLS_TO_CHECK mach_absolute_time)
    endif()
endif()

# Add stdio.h for vasprintf
set(EVENT_INCLUDES ${EVENT_INCLUDES} stdio.h)
CHECK_SYMBOLS_EXIST("${SYMBOLS_TO_CHECK}" "${EVENT_INCLUDES}" "EVENT")
unset(SYMBOLS_TO_CHECK)
set(EVENT__HAVE_EPOLL ${EVENT__HAVE_EPOLL_CREATE})

# Get the gethostbyname_r prototype.
if(EVENT__HAVE_GETHOSTBYNAME_R)
    CHECK_PROTOTYPE_DEFINITION(gethostbyname_r
        "int gethostbyname_r(const char *name, struct hostent *hp, struct hostent_data *hdata)"
        "0"
        "netdb.h"
        EVENT__HAVE_GETHOSTBYNAME_R_3_ARG)

    CHECK_PROTOTYPE_DEFINITION(gethostbyname_r
        "struct hostent *gethostbyname_r(const char *name, struct hostent *hp, char *buf, size_t buflen, int *herr)"
        "NULL"
        "netdb.h"
        EVENT__HAVE_GETHOSTBYNAME_R_5_ARG)

    CHECK_PROTOTYPE_DEFINITION(gethostbyname_r
        "int gethostbyname_r(const char *name, struct hostent *hp, char *buf, size_t buflen, struct hostent **result, int *herr)"
        "0"
        "netdb.h"
        EVENT__HAVE_GETHOSTBYNAME_R_6_ARG)
endif()

if(HAVE_PORT_H AND HAVE_PORT_CREATE)
    set(EVENT__HAVE_EVENT_PORTS 1)
endif()

# Only `CHECK_TYPE_SIZE()' will use `CMAKE_EXTRA_INCLUDE_FILES'
set(CMAKE_EXTRA_INCLUDE_FILES ${EVENT_INCLUDES})

CHECK_TYPE_SIZE("struct sockaddr_un" EVENT__HAVE_STRUCT_SOCKADDR_UN)
CHECK_TYPE_SIZE("uint8_t" EVENT__HAVE_UINT8_T)
CHECK_TYPE_SIZE("uint16_t" EVENT__HAVE_UINT16_T)
CHECK_TYPE_SIZE("uint32_t" EVENT__HAVE_UINT32_T)
CHECK_TYPE_SIZE("uint64_t" EVENT__HAVE_UINT64_T)
CHECK_TYPE_SIZE("short" EVENT__SIZEOF_SHORT BUILTIN_TYPES_ONLY)
CHECK_TYPE_SIZE("int" EVENT__SIZEOF_INT BUILTIN_TYPES_ONLY)
CHECK_TYPE_SIZE("unsigned" EVENT__SIZEOF_UNSIGNED BUILTIN_TYPES_ONLY)
CHECK_TYPE_SIZE("unsigned int" EVENT__SIZEOF_UNSIGNED_INT BUILTIN_TYPES_ONLY)
CHECK_TYPE_SIZE("long" EVENT__SIZEOF_LONG BUILTIN_TYPES_ONLY)
CHECK_TYPE_SIZE("long long" EVENT__SIZEOF_LONG_LONG BUILTIN_TYPES_ONLY)

if(WIN32)
    # These aren't available until Windows Vista.
    # But you can still link them. They just won't be found when running the exe.
    set(EVENT__HAVE_INET_NTOP 0)
    set(EVENT__HAVE_INET_PTON 0)
endif()

# Check for different inline keyword versions.
check_function_keywords("inline" "__inline" "__inline__")

if (HAVE_INLINE)
    set(EVENT__inline inline)
elseif (HAVE___INLINE)
    set(EVENT__inline __inline)
elseif(HAVE___INLINE__)
    set(EVENT__inline __inline__)
else()
    set(EVENT__inline)
endif()

# __func__/__FUNCTION__ is not a macros in general
CHECK_SYMBOL_EXISTS("__func__"     "" EVENT__HAVE___func__)
CHECK_SYMBOL_EXISTS("__FUNCTION__" "" EVENT__HAVE___FUNCTION__)

CHECK_SYMBOL_EXISTS(TAILQ_FOREACH sys/queue.h EVENT__HAVE_TAILQFOREACH)
CHECK_CONST_EXISTS(CTL_KERN sys/sysctl.h EVENT__HAVE_DECL_CTL_KERN)
CHECK_CONST_EXISTS(KERN_ARND sys/sysctl.h EVENT__HAVE_DECL_KERN_ARND)
CHECK_SYMBOL_EXISTS(F_SETFD fcntl.h EVENT__HAVE_SETFD)

CHECK_TYPE_SIZE(fd_mask EVENT__HAVE_FD_MASK)

CHECK_TYPE_SIZE(size_t EVENT__SIZEOF_SIZE_T)
if(NOT EVENT__SIZEOF_SIZE_T)
  set(EVENT__size_t "unsigned")
  set(EVENT__SIZEOF_SIZE_T ${EVENT__SIZEOF_UNSIGNED})
else()
    set(EVENT__size_t size_t)
endif()

CHECK_TYPE_SIZE("off_t" EVENT__SIZEOF_OFF_T LANGUAGE C)


# XXX we should functionalize these size and type sets. --elley

# Winssck.
if (_MSC_VER)
    list(APPEND CMAKE_EXTRA_INCLUDE_FILES BaseTsd.h)
endif()
CHECK_TYPE_SIZE("ssize_t" EVENT__SIZEOF_SSIZE_T_LOWER LANGUAGE C)
CHECK_TYPE_SIZE("SSIZE_T" EVENT__SIZEOF_SSIZE_T_UPPER LANGUAGE C)

if (EVENT__SIZEOF_SSIZE_T_LOWER)
    set(EVENT__ssize_t "ssize_t")
    set(EVENT__SIZEOF_SSIZE_T ${EVENT__SIZEOF_SSIZE_T_LOWER})
elseif (EVENT__SIZEOF_SSIZE_T_UPPER)
    set(EVENT__ssize_t "SSIZE_T")
    set(EVENT__SIZEOF_SSIZE_T ${EVENT__SIZEOF_SSIZE_T_UPPER})
else()
    set(EVENT__ssize_t "int")
    set(EVENT__SIZEOF_SSIZE_T ${EVENT__SIZEOF_INT})
endif()

CHECK_TYPE_SIZE(socklen_t EVENT__SIZEOF_SOCKLEN_T)
if(NOT EVENT__SIZEOF_SOCKLEN_T)
  set(EVENT__socklen_t "unsigned int")
  set(EVENT__SIZEOF_SOCKLEN_T ${EVENT__SIZEOF_UNSIGNED_INT})
else()
    set(EVENT__socklen_t "socklen_t")
endif()

CHECK_TYPE_SIZE(pid_t EVENT__SIZEOF_PID_T)
if(NOT EVENT__SIZEOF_PID_T)
  set(EVENT__SIZEOF_PID_T ${EVENT__SIZEOF_INT})
else()
	set(EVENT__SIZEOF_PID_T EVENT__SIZEOF_PID_T)
endif()

if (NOT EVENT__DISABLE_THREAD_SUPPORT)
    if (NOT WIN32)
        list(APPEND CMAKE_EXTRA_INCLUDE_FILES pthread.h)
    endif()
    CHECK_TYPE_SIZE(pthread_t EVENT__SIZEOF_PTHREAD_T)
endif()

if(EVENT__HAVE_CLOCK_GETTIME)
  set(EVENT__DNS_USE_CPU_CLOCK_FOR_ID 1)
endif()

# we're just getting lazy now.
CHECK_TYPE_SIZE("uintptr_t" EVENT__HAVE_UINTPTR_T)
CHECK_TYPE_SIZE("void *" EVENT__SIZEOF_VOID_P)
CHECK_TYPE_SIZE("time_t" EVENT__SIZEOF_TIME_T)

# Tests file offset bits.
# TODO: Add AIX test for if -D_LARGE_FILES is needed.

# XXX: Why is this here? we don't even use it. Well, we don't even use it
#      on top of that, why is it set in the config.h?! IT_MAKES_NO_SENSE
#      I'm commenting it out for now.
#      - ellzey

#CHECK_FILE_OFFSET_BITS()

# Verify kqueue works with pipes.
if (EVENT__HAVE_KQUEUE)
    if ((CMAKE_CROSSCOMPILING OR APPLE) AND NOT EVENT__FORCE_KQUEUE_CHECK)
        message(WARNING "Cannot check if kqueue works with pipes when crosscompiling, use EVENT__FORCE_KQUEUE_CHECK to be sure (this requires manually running a test program on the cross compilation target)")
        set(EVENT__HAVE_WORKING_KQUEUE 1)
    else()
        message(STATUS "Checking if kqueue works with pipes...")
        include(CheckWorkingKqueue)
    endif()
endif()

if(EVENT__HAVE_NETDB_H)
    list(APPEND CMAKE_EXTRA_INCLUDE_FILES netdb.h)
    CHECK_TYPE_SIZE("struct addrinfo" EVENT__HAVE_STRUCT_ADDRINFO)
elseif(WIN32)
    list(APPEND CMAKE_EXTRA_INCLUDE_FILES ws2tcpip.h)
    CHECK_TYPE_SIZE("struct addrinfo" EVENT__HAVE_STRUCT_ADDRINFO)
endif()

# Check for sockaddr structure sizes.
set(SOCKADDR_HEADERS)
if (WIN32)
    set(CMAKE_REQUIRED_DEFINITIONS "-DWIN32_LEAN_AND_MEAN")
    if (_MSC_VER LESS 1300)
        set(SOCKADDR_HEADERS winsock.h)
    else()
        set(SOCKADDR_HEADERS winsock2.h ws2tcpip.h)
    endif()
else()
    if (EVENT__HAVE_NETINET_IN_H)
        set(SOCKADDR_HEADERS ${SOCKADDR_HEADERS} netinet/in.h)
    endif()

    if (EVENT__HAVE_NETINET_IN6_H)
        set(SOCKADDR_HEADERS ${SOCKADDR_HEADERS} netinet/in6.h)
    endif()

    if (EVENT__HAVE_SYS_SOCKET_H)
        set(SOCKADDR_HEADERS ${SOCKADDR_HEADERS} sys/socket.h)
    endif()

    if (EVENT__HAVE_NETDB_H)
        set(SOCKADDR_HEADERS ${SOCKADDR_HEADERS} netdb.h)
    endif()
endif()

CHECK_TYPE_SIZE("struct in6_addr" EVENT__HAVE_STRUCT_IN6_ADDR)
if(EVENT__HAVE_STRUCT_IN6_ADDR)
    CHECK_STRUCT_HAS_MEMBER("struct in6_addr"
            s6_addr16 "${SOCKADDR_HEADERS}"
            EVENT__HAVE_STRUCT_IN6_ADDR_S6_ADDR16)

    CHECK_STRUCT_HAS_MEMBER("struct in6_addr"
            s6_addr32 "${SOCKADDR_HEADERS}"
            EVENT__HAVE_STRUCT_IN6_ADDR_S6_ADDR32)
endif()

CHECK_TYPE_SIZE("sa_family_t" EVENT__HAVE_SA_FAMILY_T)
CHECK_TYPE_SIZE("struct sockaddr_in6" EVENT__HAVE_STRUCT_SOCKADDR_IN6)

if(EVENT__HAVE_STRUCT_SOCKADDR_IN6)
    CHECK_STRUCT_HAS_MEMBER("struct sockaddr_in6"
            sin6_len "${SOCKADDR_HEADERS}"
            EVENT__HAVE_STRUCT_SOCKADDR_IN6_SIN6_LEN)

    CHECK_STRUCT_HAS_MEMBER("struct sockaddr_in6"
            sin_len "${SOCKADDR_HEADERS}"
            EVENT__HAVE_STRUCT_SOCKADDR_IN_SIN_LEN)
endif()

CHECK_TYPE_SIZE("struct sockaddr_storage" EVENT__HAVE_STRUCT_SOCKADDR_STORAGE)
if(EVENT__HAVE_STRUCT_SOCKADDR_STORAGE)
    CHECK_STRUCT_HAS_MEMBER("struct sockaddr_storage"
            ss_family "${SOCKADDR_HEADERS}"
            EVENT__HAVE_STRUCT_SOCKADDR_STORAGE_SS_FAMILY)

    CHECK_STRUCT_HAS_MEMBER("struct sockaddr_storage"
            __ss_family "${SOCKADDR_HEADERS}" EVENT__HAVE_STRUCT_SOCKADDR_STORAGE___SS_FAMILY)
endif()

CHECK_TYPE_SIZE("struct linger" EVENT__HAVE_STRUCT_LINGER)

# Group the source files.
set(HDR_PRIVATE
    bufferevent-internal.h
    changelist-internal.h
    defer-internal.h
    epolltable-internal.h
    evbuffer-internal.h
    event-internal.h
    evmap-internal.h
    evrpc-internal.h
    evsignal-internal.h
    evthread-internal.h
    ht-internal.h
    http-internal.h
    iocp-internal.h
    ipv6-internal.h
    log-internal.h
    minheap-internal.h
    mm-internal.h
    ratelim-internal.h
    strlcpy-internal.h
    util-internal.h
    evconfig-private.h
    compat/sys/queue.h)

set(HDR_COMPAT
    include/evdns.h
    include/evrpc.h
    include/event.h
    include/evhttp.h
    include/evutil.h)

set(HDR_PUBLIC
    include/event2/buffer.h
    include/event2/bufferevent.h
    include/event2/bufferevent_compat.h
    include/event2/bufferevent_struct.h
    include/event2/buffer_compat.h
    include/event2/dns.h
    include/event2/dns_compat.h
    include/event2/dns_struct.h
    include/event2/event.h
    include/event2/event_compat.h
    include/event2/event_struct.h
    include/event2/http.h
    include/event2/http_compat.h
    include/event2/http_struct.h
    include/event2/keyvalq_struct.h
    include/event2/listener.h
    include/event2/rpc.h
    include/event2/rpc_compat.h
    include/event2/rpc_struct.h
    include/event2/tag.h
    include/event2/tag_compat.h
    include/event2/thread.h
    include/event2/util.h
    include/event2/visibility.h
    ${PROJECT_BINARY_DIR}/include/event2/event-config.h)

set(SRC_CORE
    buffer.c
    bufferevent.c
    bufferevent_filter.c
    bufferevent_pair.c
    bufferevent_ratelim.c
    bufferevent_sock.c
    event.c
    evmap.c
    evthread.c
    evutil.c
    evutil_rand.c
    evutil_time.c
    listener.c
    log.c
    signal.c
    strlcpy.c)

if(EVENT__HAVE_SELECT)
    list(APPEND SRC_CORE select.c)
endif()

if(EVENT__HAVE_POLL)
    list(APPEND SRC_CORE poll.c)
endif()

if(EVENT__HAVE_KQUEUE)
    list(APPEND SRC_CORE kqueue.c)
endif()

if(EVENT__HAVE_DEVPOLL)
    list(APPEND SRC_CORE devpoll.c)
endif()

if(EVENT__HAVE_EPOLL)
    list(APPEND SRC_CORE epoll.c)
endif()

if(EVENT__HAVE_EVENT_PORTS)
    list(APPEND SRC_CORE evport.c)
endif()

if (NOT EVENT__DISABLE_OPENSSL)
    find_package(OpenSSL REQUIRED)

    set(EVENT__HAVE_OPENSSL 1)

    message(STATUS "OpenSSL include: ${OPENSSL_INCLUDE_DIR}")
    message(STATUS "OpenSSL lib: ${OPENSSL_LIBRARIES}")

    include_directories(${OPENSSL_INCLUDE_DIR})

    list(APPEND SRC_OPENSSL bufferevent_openssl.c)
    list(APPEND HDR_PUBLIC include/event2/bufferevent_ssl.h)
    list(APPEND LIB_APPS ${OPENSSL_LIBRARIES})
endif()

if (NOT EVENT__DISABLE_THREAD_SUPPORT)
    if (WIN32)
        list(APPEND SRC_CORE evthread_win32.c)
    else()
        find_package(Threads REQUIRED)
        if (NOT CMAKE_USE_PTHREADS_INIT)
            message(FATAL_ERROR
                    "Failed to find Pthreads, set EVENT__DISABLE_THREAD_SUPPORT to disable")
        endif()

        set(EVENT__HAVE_PTHREADS 1)
        list(APPEND LIB_APPS ${CMAKE_THREAD_LIBS_INIT})
    endif()
endif()

if (NOT EVENT__DISABLE_TESTS)
    # Zlib is only used for testing.
    find_package(ZLIB)

    if (ZLIB_LIBRARY AND ZLIB_INCLUDE_DIR)
        include_directories(${ZLIB_INCLUDE_DIRS})

        set(EVENT__HAVE_LIBZ 1)
        list(APPEND LIB_APPS ${ZLIB_LIBRARIES})
    endif()
endif()

set(SRC_EXTRA
    event_tagging.c
    http.c
    evdns.c
    evrpc.c)

add_definitions(-DHAVE_CONFIG_H)

# We use BEFORE here so we don't accidentally look in system directories
# first for some previous versions of the headers that are installed.
include_directories(BEFORE ${PROJECT_SOURCE_DIR}
    ${PROJECT_SOURCE_DIR}/compat
    ${PROJECT_SOURCE_DIR}/include)

if(WIN32)
    list(APPEND SRC_CORE
        buffer_iocp.c
        bufferevent_async.c
        event_iocp.c
        win32select.c)

    list(APPEND HDR_PRIVATE WIN32-Code/getopt.h)

    set(EVENT__DNS_USE_FTIME_FOR_ID 1)
    set(LIB_PLATFORM ws2_32 shell32 advapi32)
    add_definitions(
            -D_CRT_SECURE_NO_WARNINGS
            -D_CRT_NONSTDC_NO_DEPRECATE)

    include_directories(./WIN32-Code)
endif()

if (SOLARIS)
    list(APPEND LIB_PLATFORM socket nsl)
endif()

source_group("Headers Private"  FILES ${HDR_PRIVATE})
source_group("Header Compat"    FILES ${HDR_COMPAT})
source_group("Headers Public"   FILES ${HDR_PUBLIC})
source_group("Source Core"      FILES ${SRC_CORE})
source_group("Source Extra"     FILES ${SRC_EXTRA})

# Generate the configure headers.
# (Place them in the build dir so we don't polute the source tree with generated files).
include_directories(BEFORE ${CMAKE_CURRENT_BINARY_DIR}/include)

if (${GNUC})
    set(EVENT_SHARED_FLAGS -fvisibility=hidden)
elseif ("${CMAKE_C_COMPILER_ID}" STREQUAL "SunPro")
    set(EVENT_SHARED_FLAGS -xldscope=hidden)
endif()

configure_file(
    ${CMAKE_CURRENT_SOURCE_DIR}/event-config.h.cmake
    ${CMAKE_CURRENT_BINARY_DIR}/include/event2/event-config.h
        NEWLINE_STYLE UNIX)

configure_file(
    ${CMAKE_CURRENT_SOURCE_DIR}/evconfig-private.h.cmake
    ${CMAKE_CURRENT_BINARY_DIR}/include/evconfig-private.h)

#
# Create the libraries.
#
include(AddEventLibrary)
add_event_library(event_core SOURCES ${SRC_CORE})
add_event_library(event_extra
    INNER_LIBRARIES event_core
    SOURCES ${SRC_EXTRA})

if (NOT EVENT__DISABLE_OPENSSL)
    add_event_library(event_openssl
        INNER_LIBRARIES event_core
        OUTER_INCLUDES ${OPENSSL_INCLUDE_DIR}
        LIBRARIES ${OPENSSL_LIBRARIES}
        SOURCES ${SRC_OPENSSL})
endif()

if (EVENT__HAVE_PTHREADS)
    set(SRC_PTHREADS evthread_pthread.c)
    add_event_library(event_pthreads
        INNER_LIBRARIES event_core
        SOURCES ${SRC_PTHREADS})
endif()

# library exists for historical reasons; it contains the contents of
# both libevent_core and libevent_extra. You shouldn’t use it; it may
# go away in a future version of Libevent.
add_event_library(event SOURCES ${SRC_CORE} ${SRC_EXTRA})

set(WIN32_GETOPT)
if (WIN32)
    set(_TMPLIBS)
    if (${EVENT_LIBRARY_STATIC})
        list(APPEND _TMPLIBS event_core_static event_static)
    endif()
    if (${EVENT_LIBRARY_SHARED})
        list(APPEND _TMPLIBS event_core_shared event_shared)
    endif()
    foreach(lib ${_TMPLIBS})
        target_link_libraries(${lib} iphlpapi)
    endforeach()
    unset(_TMPLIBS)

    list(APPEND WIN32_GETOPT
         WIN32-Code/getopt.c
         WIN32-Code/getopt_long.c)
endif()

#
# Samples.
#
macro(add_sample_prog ssl name)
    add_executable(${name} ${ARGN})

    target_link_libraries(${name}
                          event_extra
                          event_core
                          ${LIB_APPS}
                          ${LIB_PLATFORM})

    if (${ssl})
        target_link_libraries(${name} event_openssl)
        if(WIN32)
            target_link_libraries(${name} crypt32)
        endif()
    endif()
endmacro()
if (NOT EVENT__DISABLE_SAMPLES)
    set(SAMPLES
        event-read-fifo
        hello-world
        signal-test
        http-connect
        time-test)

    foreach(SAMPLE ${SAMPLES})
        add_sample_prog(OFF ${SAMPLE} sample/${SAMPLE}.c)
    endforeach()

    if (NOT EVENT__DISABLE_OPENSSL)
        add_sample_prog(ON https-client
                        sample/https-client.c
                        sample/openssl_hostname_validation.c
                        sample/hostcheck.c)
        add_sample_prog(ON le-proxy
                        sample/le-proxy.c)
    endif()

    set(SAMPLES_WOPT
        dns-example
        http-server
    )
    foreach (SAMPLE ${SAMPLES_WOPT})
        add_sample_prog(OFF ${SAMPLE} sample/${SAMPLE}.c ${WIN32_GETOPT})
    endforeach()
endif()

#
# Benchmarks
#
macro(add_bench_prog prog)
    add_executable(${prog} ${ARGN})
    target_link_libraries(${prog}
                          event_extra
                          event_core
                          ${LIB_APPS}
                          ${LIB_PLATFORM})
endmacro()
if (NOT EVENT__DISABLE_BENCHMARK)
    foreach (BENCHMARK bench_http bench_httpclient)
        add_bench_prog(${BENCHMARK} test/${BENCHMARK}.c)
    endforeach()

    add_bench_prog(bench test/bench.c ${WIN32_GETOPT})
    add_bench_prog(bench_cascade test/bench_cascade.c ${WIN32_GETOPT})
endif()

#
# Tests
#
macro(add_test_prog prog)
    add_executable(${prog} test/${prog}.c)
    target_link_libraries(${prog}
                          ${LIB_APPS}
                          ${LIB_PLATFORM}
                          event_core
                          event_extra
                          ${ARGN})
endmacro()
if (NOT EVENT__DISABLE_TESTS)
    #
    # Generate Regress tests.
    #
    if (NOT EVENT__DISABLE_REGRESS)
        # (We require python to generate the regress tests)
        find_package(PythonInterp 3)

        if (PYTHONINTERP_FOUND)
            set(__FOUND_USABLE_PYTHON 1)
        else()
            find_package(PythonInterp 2)
            if (PYTHONINTERP_FOUND)
                set(__FOUND_USABLE_PYTHON 1)
            else()
                message(ERROR "No suitable Python version found, bailing...")
            endif()
        endif()

        if (__FOUND_USABLE_PYTHON)
            message(STATUS "Generating regress tests...")

            add_definitions(-DTINYTEST_LOCAL)

            add_custom_command(
                OUTPUT
                    ${CMAKE_CURRENT_SOURCE_DIR}/test/regress.gen.c
                    ${CMAKE_CURRENT_SOURCE_DIR}/test/regress.gen.h
                DEPENDS
                    event_rpcgen.py
                    test/regress.rpc
                COMMAND ${PYTHON_EXECUTABLE} ../event_rpcgen.py --quiet regress.rpc
                WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/test)

            list(APPEND SRC_REGRESS
                 test/regress.c
                 test/regress.gen.c
                 test/regress.gen.h
                 test/regress_buffer.c
                 test/regress_bufferevent.c
                 test/regress_dns.c
                 test/regress_et.c
                 test/regress_finalize.c
                 test/regress_http.c
                 test/regress_listener.c
                 test/regress_main.c
                 test/regress_minheap.c
                 test/regress_rpc.c
                 test/regress_testutils.c
                 test/regress_testutils.h
                 test/regress_util.c
                 test/tinytest.c)

            if (WIN32)
                list(APPEND SRC_REGRESS test/regress_iocp.c)
                if (NOT EVENT__DISABLE_THREAD_SUPPORT)
                    list(APPEND SRC_REGRESS test/regress_thread.c)
                endif()
            elseif (EVENT__HAVE_PTHREADS)
                list(APPEND SRC_REGRESS test/regress_thread.c)
            endif()

            if (ZLIB_LIBRARY AND ZLIB_INCLUDE_DIR)
                list(APPEND SRC_REGRESS test/regress_zlib.c)
            endif()

            if (NOT EVENT__DISABLE_OPENSSL)
                list(APPEND SRC_REGRESS test/regress_ssl.c)
            endif()

            add_executable(regress ${SRC_REGRESS})

            target_link_libraries(regress
                                  ${LIB_APPS}
                                  ${LIB_PLATFORM}
                                  event_core
                                  event_extra)
            if (NOT EVENT__DISABLE_OPENSSL)
                target_link_libraries(regress event_openssl)
            endif()
            if (CMAKE_USE_PTHREADS_INIT)
                target_link_libraries(regress event_pthreads)
            endif()
        else()
            message(WARNING "No suitable Python interpreter found, cannot generate regress tests!")
        endif()
    endif()

    #
    # Test programs.
    #
    # all of these, including the cmakelists.txt should be moved
    # into the dirctory 'tests' first.
    #
    # doing this, we can remove all the DISABLE_TESTS stuff, and simply
    # do something like:
    #
    # add_custom_targets(tests)
    # add_executable(... EXCLUDE_FROM_ALL ...c)
    # add_dependencis(tests testa testb testc)
    # add_test(....)
    #
    # then you can just run 'make tests' instead of them all
    # auto-compile|running
    # - ellzey
    set(TESTPROGS test-changelist
                  test-eof
                  test-closed
                  test-fdleak
                  test-init
                  test-time
                  test-weof)

    foreach (TESTPROG ${TESTPROGS} test-dumpevents)
        add_test_prog(${TESTPROG})
    endforeach()
    if (UNIX)
        add_test_prog(test-ratelim m)
    else()
        add_test_prog(test-ratelim)
    endif()

    set(ALL_TESTPROGS
        ${TESTPROGS}
        test-dumpevents
        test-ratelim
    )

    #
    # We run all tests with the different backends turned on one at a time.
    #

    # Add event backends based on system introspection result.
    set(BACKENDS "")

    if (EVENT__HAVE_EPOLL)
        list(APPEND BACKENDS EPOLL)
    endif()

    if (EVENT__HAVE_SELECT)
        list(APPEND BACKENDS SELECT)
    endif()

    if (EVENT__HAVE_POLL)
        list(APPEND BACKENDS POLL)
    endif()

    if (EVENT__HAVE_KQUEUE)
        list(APPEND BACKENDS KQUEUE)
    endif()

    if (EVENT__HAVE_EVENT_PORTS)
        list(APPEND BACKENDS EVPORT)
    endif()

    if (EVENT__HAVE_DEVPOLL)
        list(APPEND BACKENDS DEVPOLL)
    endif()

    if (WIN32)
        list(APPEND BACKENDS WIN32)
    endif()


    # Default environment variables turns off all event systems,
    # then we enable each one, one at a time when creating the tests.
    set(DEFAULT_TEST_ENV_VARS)
    foreach(BACKEND ${BACKENDS})
        set(BACKEND_ENV_VAR "EVENT_NO${BACKEND}=1")
        list(APPEND DEFAULT_TEST_ENV_VARS "${BACKEND_ENV_VAR}")
    endforeach()

    # Macro that creates the ctest test for a backend.
    macro(add_backend_test BACKEND_TEST_NAME ENV_VARS)
        set(TEST_NAMES "")

        foreach (TESTPROG ${TESTPROGS})
            set(TEST_NAME ${TESTPROG}__${BACKEND_TEST_NAME})

            add_test(${TEST_NAME}
                     ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/${TESTPROG})

            list(APPEND TEST_NAMES ${TEST_NAME})

            set_tests_properties(${TEST_NAME}
                                 PROPERTIES ENVIRONMENT "${ENV_VARS}")
        endforeach()

        # Dump events test.
        if (__FOUND_USABLE_PYTHON)
            set(TEST_NAME test-dumpevents__${BACKEND_TEST_NAME})

            add_test(${TEST_NAME}
                     ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/test-dumpevents |
                     ${PYTHON_EXECUTABLE}
                     ${CMAKE_CURRENT_SOURCE_DIR}/test/check-dumpevents.py)

            set_tests_properties(${TEST_NAME}
                                 PROPERTIES ENVIRONMENT "${ENV_VARS}")
        else()
            message(WARNING "test-dumpevents will be run without output check since python was not found!")
            set(TEST_NAME test-dumpevents__${BACKEND_TEST_NAME}_no_check)

            add_test(${TEST_NAME}
                     ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/test-dumpevents)

            set_tests_properties(${TEST_NAME}
                                 PROPERTIES ENVIRONMENT "${ENV_VARS}")
        endif()

        # Regress tests.
        if (NOT EVENT__DISABLE_REGRESS AND __FOUND_USABLE_PYTHON)
            set(TEST_NAME regress__${BACKEND_TEST_NAME})

            add_test(${TEST_NAME}
                     ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/regress --quiet)

            set_tests_properties(${TEST_NAME}
                                 PROPERTIES ENVIRONMENT "${ENV_VARS}")

            add_test(${TEST_NAME}_debug
                     ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/regress --quiet)

            set_tests_properties(${TEST_NAME}_debug
                                 PROPERTIES ENVIRONMENT "${ENV_VARS};EVENT_DEBUG_MODE=1")
        endif()
    endmacro()

    # Add the tests for each backend.
    foreach(BACKEND ${BACKENDS})
        # Enable this backend only.
        set(BACKEND_ENV_VARS ${DEFAULT_TEST_ENV_VARS})
        list(REMOVE_ITEM BACKEND_ENV_VARS EVENT_NO${BACKEND}=1)

        # Epoll has some extra settings.
        if (${BACKEND} STREQUAL "EPOLL")
            add_backend_test(timerfd_${BACKEND}
                            "${BACKEND_ENV_VARS};EVENT_PRECISE_TIMER=1")

            add_backend_test(changelist_${BACKEND}
                            "${BACKEND_ENV_VARS};EVENT_EPOLL_USE_CHANGELIST=yes")

            add_backend_test(timerfd_changelist_${BACKEND}
                            "${BACKEND_ENV_VARS};EVENT_EPOLL_USE_CHANGELIST=yes;EVENT_PRECISE_TIMER=1")
        else()
            add_backend_test(${BACKEND} "${BACKEND_ENV_VARS}")
        endif()
    endforeach()

    #
    # Rate limiter tests.
    #

    # Group limits, no connection limit.
    set(RL_BIN ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/test-ratelim)

    add_test(test-ratelim__group_lim
             ${RL_BIN}
             -g 30000
             -n 30
             -t 100
             --check-grouplimit 1000
             --check-stddev 100)

    # Connection limit, no group limit.
    add_test(test-ratelim__con_lim
             ${RL_BIN}
             -c 1000
             -n 30
             -t 100
             --check-connlimit 50
             --check-stddev 50)

    # Connection limit and group limit.
    add_test(test-ratelim__group_con_lim
             ${RL_BIN}
             -c 1000
             -g 30000
             -n 30
             -t 100
             --check-grouplimit 1000
             --check-connlimit 50
             --check-stddev 50)

    # Connection limit and group limit with independent drain.
    add_test(test-ratelim__group_con_lim_drain
             ${RL_BIN}
             -c 1000
             -g 35000
             -n 30
             -t 100
             -G 500
             --check-grouplimit 1000
             --check-connlimit 50
             --check-stddev 50)

    # Add a "make verify" target, same as for autoconf.
    # (Important! This will unset all EVENT_NO* environment variables.
    #  If they are set in the shell the tests are running using simply "ctest" or "make test" will fail)
    if (WIN32)
        # Windows doesn't have "unset". But you can use "set VAR=" instead.
        # We need to guard against the possibility taht EVENT_NOWIN32 is set, and all test failing
        # since no event backend being available.
        file(TO_NATIVE_PATH ${CMAKE_CTEST_COMMAND} WINDOWS_CTEST_COMMAND)

        file(WRITE ${CMAKE_CURRENT_BINARY_DIR}/tmp/verify_tests.bat
            "
            set EVENT_NOWIN32=
            \"${WINDOWS_CTEST_COMMAND}\"
            ")

        message(STATUS "${WINDOWS_CTEST_COMMAND}")

        file(COPY ${CMAKE_CURRENT_BINARY_DIR}/tmp/verify_tests.bat
             DESTINATION ${CMAKE_CURRENT_BINARY_DIR}
             FILE_PERMISSIONS
                             OWNER_READ
                             OWNER_WRITE
                             OWNER_EXECUTE
                             GROUP_READ
                             GROUP_EXECUTE
                             WORLD_READ WORLD_EXECUTE)

        file(TO_NATIVE_PATH
                    "${CMAKE_CURRENT_BINARY_DIR}/verify_tests.bat" VERIFY_PATH)

        add_custom_target(verify COMMAND "${VERIFY_PATH}"
                          DEPENDS event ${ALL_TESTPROGS})
    else()
        # On some platforms doing exec(unset) as CMake does won't work, so make sure
        # we run the unset command in a shell instead.
        # First we write the script contents.
        file(WRITE ${CMAKE_CURRENT_BINARY_DIR}/tmp/verify_tests.sh
            "
            #!/bin/bash
            unset EVENT_NOEPOLL; unset EVENT_NOPOLL; unset EVENT_NOSELECT; unset EVENT_NOWIN32; unset EVENT_NOEVPORT; unset EVENT_NOKQUEUE; unset EVENT_NODEVPOLL
            ${CMAKE_CTEST_COMMAND}
            ")

        # Then we copy the file (this allows us to set execute permission on it)
        file(COPY ${CMAKE_CURRENT_BINARY_DIR}/tmp/verify_tests.sh
             DESTINATION ${CMAKE_CURRENT_BINARY_DIR}
             FILE_PERMISSIONS
                             OWNER_READ
                             OWNER_WRITE
                             OWNER_EXECUTE
                             GROUP_READ
                             GROUP_EXECUTE
                             WORLD_READ
                             WORLD_EXECUTE)

        # Create the target that runs the script.
        add_custom_target(verify
                          COMMAND ${CMAKE_CURRENT_BINARY_DIR}/verify_tests.sh
                          DEPENDS event ${ALL_TESTPROGS})
    endif()

    if (NOT EVENT__DISABLE_REGRESS AND __FOUND_USABLE_PYTHON)
        add_dependencies(verify regress)
    endif()

    if (EVENT__COVERAGE)
        include(CodeCoverage)

        setup_target_for_coverage(
            verify_coverage # Coverage target name "make verify_coverage"
            make            # Test runner.
            coverage        # Output directory.
            verify)         # Arguments passed to test runner. "make verify"
    endif()

    enable_testing()

    include(CTest)
endif()

#
# Installation preparation.
#

set(EVENT_INSTALL_CMAKE_DIR
    "${CMAKE_INSTALL_PREFIX}/lib/cmake/libevent")

export(PACKAGE libevent)

function(gen_package_config forinstall)
    if(${forinstall})
        set(CONFIG_FOR_INSTALL_TREE 1)
        set(dir "${PROJECT_BINARY_DIR}${CMAKE_FILES_DIRECTORY}")
    else()
        set(CONFIG_FOR_INSTALL_TREE 0)
        set(dir "${PROJECT_BINARY_DIR}")
    endif()
    configure_file(${PROJECT_SOURCE_DIR}/cmake/LibeventConfig.cmake.in
                "${dir}/LibeventConfig.cmake"
                @ONLY)
endfunction()

# Generate the config file for the build-tree.
set(EVENT__INCLUDE_DIRS
    "${PROJECT_SOURCE_DIR}/include"
    "${PROJECT_BINARY_DIR}/include")

set(LIBEVENT_INCLUDE_DIRS
    ${EVENT__INCLUDE_DIRS}
    CACHE PATH "Libevent include directories")

gen_package_config(0)

# Generate the config file for the installation tree.
gen_package_config(1)

# Generate version info for both build-tree and install-tree.
configure_file(${PROJECT_SOURCE_DIR}/cmake/LibeventConfigVersion.cmake.in
               ${PROJECT_BINARY_DIR}/LibeventConfigVersion.cmake
               @ONLY)

# Install compat headers
install(FILES ${HDR_COMPAT}
        DESTINATION "include"
        COMPONENT dev)

# Install public headers
install(FILES ${HDR_PUBLIC}
        DESTINATION "include/event2"
        COMPONENT dev)

# Install the configs.
install(FILES
        ${PROJECT_BINARY_DIR}/${CMAKE_FILES_DIRECTORY}/LibeventConfig.cmake
        ${PROJECT_BINARY_DIR}/LibeventConfigVersion.cmake
        DESTINATION "${EVENT_INSTALL_CMAKE_DIR}"
        COMPONENT dev)

# Install exports for the install-tree.
macro(install_export type)
    install(EXPORT LibeventTargets-${type}
        NAMESPACE ${PROJECT_NAME}::
        DESTINATION "${EVENT_INSTALL_CMAKE_DIR}"
        COMPONENT dev)
endmacro()

if (${EVENT_LIBRARY_STATIC})
    install_export(static)
endif()
if (${EVENT_LIBRARY_SHARED})
    install_export(shared)
endif()

# Install the scripts.
install(PROGRAMS
       ${CMAKE_CURRENT_SOURCE_DIR}/event_rpcgen.py
       DESTINATION "bin"
       COMPONENT runtime)

# Create documents with doxygen.
option(EVENT__DOXYGEN
    "Enables doxygen documentation" OFF)
if (EVENT__DOXYGEN)
    include(UseDoxygen)
    UseDoxygen()
endif()


if (NOT TARGET uninstall)
	# Create the uninstall target.
	# https://gitlab.kitware.com/cmake/community/wikis/FAQ#can-i-do-make-uninstall-with-cmake
	configure_file(${PROJECT_SOURCE_DIR}/cmake/Uninstall.cmake.in
				   ${PROJECT_BINARY_DIR}/Uninstall.cmake
				   @ONLY)

	add_custom_target(uninstall
					  COMMAND ${CMAKE_COMMAND} -P ${PROJECT_BINARY_DIR}/Uninstall.cmake)
endif()

message(STATUS "")
message(STATUS "        ---( Libevent " ${EVENT_VERSION} " )---")
message(STATUS "")
message(STATUS "Available event backends: ${BACKENDS}")
message(STATUS "CMAKE_BINARY_DIR:         ${CMAKE_BINARY_DIR}")
message(STATUS "CMAKE_CURRENT_BINARY_DIR: ${CMAKE_CURRENT_BINARY_DIR}")
message(STATUS "CMAKE_SOURCE_DIR:         ${CMAKE_SOURCE_DIR}")
message(STATUS "CMAKE_CURRENT_SOURCE_DIR: ${CMAKE_CURRENT_SOURCE_DIR}")
message(STATUS "PROJECT_BINARY_DIR:       ${PROJECT_BINARY_DIR}")
message(STATUS "PROJECT_SOURCE_DIR:       ${PROJECT_SOURCE_DIR}")
message(STATUS "CMAKE_MODULE_PATH:        ${CMAKE_MODULE_PATH}")
message(STATUS "CMAKE_COMMAND:            ${CMAKE_COMMAND}")
message(STATUS "CMAKE_ROOT:               ${CMAKE_ROOT}")
message(STATUS "CMAKE_SYSTEM:             ${CMAKE_SYSTEM}")
message(STATUS "CMAKE_SYSTEM_NAME:        ${CMAKE_SYSTEM_NAME}")
message(STATUS "CMAKE_SYSTEM_VERSION:     ${CMAKE_SYSTEM_VERSION}")
message(STATUS "CMAKE_SYSTEM_PROCESSOR:   ${CMAKE_SYSTEM_PROCESSOR}")
message(STATUS "CMAKE_SKIP_RPATH:         ${CMAKE_SKIP_RPATH}")
message(STATUS "CMAKE_VERBOSE_MAKEFILE:   ${CMAKE_VERBOSE_MAKEFILE}")
message(STATUS "CMAKE_C_FLAGS:            ${CMAKE_C_FLAGS}")
message(STATUS "CMAKE_BUILD_TYPE:         ${CMAKE_BUILD_TYPE}")
message(STATUS "CMAKE_C_COMPILER:         ${CMAKE_C_COMPILER} (id ${CMAKE_C_COMPILER_ID}, clang ${CLANG}, GNUC ${GNUC})")
message(STATUS "CMAKE_AR:                 ${CMAKE_AR}")
message(STATUS "CMAKE_RANLIB:             ${CMAKE_RANLIB}")
message(STATUS "")

